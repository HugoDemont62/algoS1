<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>People are people</title>
    <link type="text/css" rel="stylesheet" href="css/style.css"/>
</head>
<body>

<div id="container">

    <div>
        <nav>
            <h1>People are People<span class="right"><a href="add.php">+</a></span></h1>
        </nav>
        <main>
            <div class="card">
                <a href="del.php?nom=Jane Smith">&#x2716;</a>
                <img src="imgs/avatar-district.png" alt="Avatar"/>

                <div class="container">
                    <h4><b>Jane Smith</b></h4>

                    <p>1250 points</p>

                    <div class="color" style="background-color: #B74F6F"></div>
                    <span class="bronze"/>

                </div>
            </div>
            <div class="card">
                <a href="del.php?nom=John Dow">&#x2716;</a>
                <img src="imgs/avatar-05.png" alt="Avatar"/>

                <div class="container">
                    <h4><b>John Dow</b></h4>

                    <p>1780 points</p>

                    <div class="color" style="background-color: #ADC698"></div>
                    <span class="silver"/>
                </div>
            </div>
            <div class="card">
                <a href="del.php?nom=Betty O'Brian">&#x2716;</a>
                <img src="imgs/avatar3.png" alt="Avatar"/>

                <div class="container">
                    <h4><b>Betty O'Brian</b></h4>

                    <p>2420 points</p>

                    <div class="color" style="background-color: #B74F6F"></div>
                    <span class="gold"/>

                </div>
            </div>
            <div class="card">
                <a href="del.php?nom=Jane Smith">&#x2716;</a>
                <img src="imgs/avatar_women.png" alt="Avatar"/>

                <div class="container">
                    <h4><b>Jane Smith</b></h4>

                    <p>1250 points</p>

                    <div class="color" style="background-color: #B74F6F"></div>
                    <span class="bronze"/>

                </div>
            </div>
            <div class="card">
                <a href="del.php?nom=John Dow Junior">&#x2716;</a>
                <img src="imgs/avatar-04.png" alt="Avatar"/>

                <div class="container">
                    <h4><b>John Dow Junior</b></h4>

                    <p>1990 points</p>

                    <div class="color" style="background-color: #ADC698"></div>
                    <span class="silver"/>

                </div>
            </div>
            <div class="card">
                <img src="imgs/avatar-06.png" alt="Avatar"/>
                <a href="del.php?nom=Bill Baroud">&#x2716; </a>

                <div class="container">
                    <h4><b>Bill Baroud</b></h4>

                    <p>2120 points</p>

                    <div class="color" style="background-color: #F92A82"></div>
                    <span class="gold"/>

                </div>
            </div>
    </div>

</div>
</div>

</body>
</html>