<?php
include("inputs.php");
startReadingVariables();
readVariables('nom');
endReadingVariables();
